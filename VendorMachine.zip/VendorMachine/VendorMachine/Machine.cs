﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine
{
    public class Machine : IMachine
    {
        public Machine()
        {
            AddProducts();
            AddCoins();
        }
        private List<Product> lstProducts;
        private List<Coin> lstCoins;

        public void StartMachine()
        {
            while (true)
            {
                MachineLogic();
            }
        }

        /// <summary>
        /// Reading the Inputs
        /// </summary>
        private void MachineLogic()
        {
            string insertedCoin;
            List<string> insertedCoins = new List<string>();
            Console.WriteLine("Please Enter Product Name");
            var productName = Console.ReadLine();
            Console.WriteLine("Please Enter Coins, After that please enter display");
            do
            {
                insertedCoin = Console.ReadLine();
                insertedCoins.Add(insertedCoin);
            }
            while (insertedCoin.ToLower() != "display");
            insertedCoins.RemoveAt(insertedCoins.Count - 1);
            DisplayInformation(productName, insertedCoins);
        }

        /// <summary>
        /// Calculating the Total inserted coins and matching with the Product 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="insertedCoins"></param>
        /// <returns></returns>
        public string DisplayInformation(string name, List<string> insertedCoins)
        {
            string returnString = string.Empty;
            if (string.IsNullOrEmpty(name) || insertedCoins == null || insertedCoins.Count() == 0)
                returnString = "Insert Coin";
            else
            {
                Product selectedProduct = lstProducts.Where(x => x.ProductName == name).FirstOrDefault();
                if (selectedProduct != null)
                {
                    var rejectedCoins = insertedCoins.Where(x => lstCoins.All(p => p.CoinName.ToLower() != x.ToLower())).ToList();
                    var removedCount = insertedCoins.RemoveAll(x => rejectedCoins.Contains(x));
                    if (removedCount > 0)
                        returnString = "Coins return:" + removedCount + "\n";
                    double TotalValue = 0;
                    foreach (var insertedCoin in insertedCoins)
                    {
                        TotalValue += lstCoins.Find(a => a.CoinName.ToLower() == insertedCoin.ToLower()).Price;
                    }
                    if (TotalValue < selectedProduct.ProductPrice)
                        returnString += "Product Price: " + selectedProduct.ProductPrice + ", Total Price :" + TotalValue;
                    else
                        returnString = "Thank You";
                }
                else
                {
                    returnString = "ProductName is not Valid";
                }

            }
            Console.WriteLine(returnString);
            Console.WriteLine("");
            return returnString;

        }

        /// <summary>
        /// Adding Products
        /// </summary>
        /// <returns></returns>
        public List<Product> AddProducts()
        {
            lstProducts = new List<Product>();

            Product product = new Product();
            product.ProductName = "Cola";
            product.ProductPrice = 1.00;
            lstProducts.Add(product);


            product = new Product();
            product.ProductName = "Chips";
            product.ProductPrice = 0.50;
            lstProducts.Add(product);


            product = new Product();
            product.ProductName = "Candy";
            product.ProductPrice = 0.65;
            lstProducts.Add(product);

            return lstProducts;
        }

        /// <summary>
        /// Adding Coins
        /// </summary>
        /// <returns></returns>
        public List<Coin> AddCoins()
        {
            lstCoins = new List<Coin>();

            Coin coin = new Coin();
            coin.CoinName = "nickels";
            coin.Price = 0.05;
            lstCoins.Add(coin);


            coin = new Coin();
            coin.CoinName = "Dimes";
            coin.Price = 0.1;
            lstCoins.Add(coin);


            coin = new Coin();
            coin.CoinName = "Quarters";
            coin.Price = 0.25;
            lstCoins.Add(coin);

            return lstCoins;
        }

        public bool checkValidCoin(string coin)
        {
            return lstCoins.Any(val => val.CoinName.ToLowerInvariant() == coin.ToLowerInvariant());
        }

        public bool checkValidProduct(string pName)
        {
            return lstProducts.Any(val => val.ProductName.ToLowerInvariant() == pName.ToLowerInvariant());
        }
    }
}
