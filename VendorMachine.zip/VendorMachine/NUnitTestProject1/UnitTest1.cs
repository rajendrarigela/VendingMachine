using NUnit.Framework;
using System.Collections.Generic;
using VendingMachine;

namespace Tests
{
    public class Tests
    {
        Machine m = new Machine();
        [SetUp]
        public void Setup()
        {
            m = new Machine();
            m.AddProducts();
            m.AddCoins();
        }

        [Test]
        public void TestValidProduct()
        {
            string productName = "Cola";
            Assert.AreEqual(m.checkValidProduct(productName), true);
        }

        [Test]
        public void TestInValidProduct()
        {
            string productName = "sprite";
            Assert.AreEqual(m.checkValidProduct(productName), false);
        }

        [Test]
        public void TestValidCoin()
        {
            string coinName = "dimes";
            Assert.AreEqual(m.checkValidCoin(coinName), true);
        }

        [Test]
        public void TestInValidCoin()
        {
            string coinName = "rupee";
            Assert.AreEqual(m.checkValidCoin(coinName), false);
        }

        [Test]
        public void TestMachinetwo()
        {
            string productName = "Chips";
            List<string> lstCoins = new List<string> { "quarters", "nickels" };
            Assert.AreEqual(m.DisplayInformation(productName, lstCoins), "Product Price: 0.5, Total Price :0.3");
        }
        [Test]
        public void TestMachinethree()
        {
            string productName = "Cola";
            List<string> lstCoins = new List<string> { };
            Assert.AreEqual(m.DisplayInformation(productName, lstCoins), "Insert Coin");
        }
    }
}